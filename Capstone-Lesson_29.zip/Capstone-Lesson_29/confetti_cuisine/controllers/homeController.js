// "use strict";

// module.exports = {
//   index: (req, res) => {
//     res.render("index");
//   }
// };


// Debugging version

"use strict";

module.exports = {
  index: (req, res) => {
    // 1. Log that the route handler has been successfully triggered
    console.log("\n==============================================");
    console.log("🔍 DEBUGGER: homeController.index action triggered!");
    console.log("==============================================");

    // 2. Log details about the incoming HTTP request
    console.log(`📱 Request Method: ${req.method}`);
    console.log(`📍 Request URL: ${req.url}`);
    console.log(`🌐 Client IP: ${req.ip}`);

    // 3. Log what the controller is about to do next
    console.log("🎨 Action: Rendering the 'index.ejs' view template...");

    // Render the home page view
    res.render("index");

    // 4. Confirm the response process is complete
    console.log("✅ Success: 'index' view successfully sent to the browser.\n");
  }
};