// "use strict";

// const User = require("../models/user"),
//   getUserParams = body => {
//     return {
//       name: {
//         first: body.first,
//         last: body.last
//       },
//       email: body.email,
//       password: body.password,
//       zipCode: body.zipCode
//     };
//   };

// module.exports = {
//   index: (req, res, next) => {
//     User.find()
//       .then(users => {
//         res.locals.users = users;
//         next();
//       })
//       .catch(error => {
//         console.log(`Error fetching users: ${error.message}`);
//         next(error);
//       });
//   },
//   indexView: (req, res) => {
//     res.render("users/index");
//   },

//   new: (req, res) => {
//     res.render("users/new");
//   },

//   create: (req, res, next) => {
//     let userParams = getUserParams(req.body);

//     User.create(userParams)
//       .then(user => {
//         res.locals.redirect = "/users";
//         res.locals.user = user;
//         next();
//       })
//       .catch(error => {
//         console.log(`Error saving user: ${error.message}`);
//         next(error);
//       });
//   },

//   redirectView: (req, res, next) => {
//     let redirectPath = res.locals.redirect;
//     if (redirectPath !== undefined) res.redirect(redirectPath);
//     else next();
//   },

//   show: (req, res, next) => {
//     let userId = req.params.id;
//     User.findById(userId)
//       .then(user => {
//         res.locals.user = user;
//         next();
//       })
//       .catch(error => {
//         console.log(`Error fetching user by ID: ${error.message}`);
//         next(error);
//       });
//   },

//   showView: (req, res) => {
//     res.render("users/show");
//   },

//   edit: (req, res, next) => {
//     let userId = req.params.id;
//     User.findById(userId)
//       .then(user => {
//         res.render("users/edit", {
//           user: user
//         });
//       })
//       .catch(error => {
//         console.log(`Error fetching user by ID: ${error.message}`);
//         next(error);
//       });
//   },

//   update: (req, res, next) => {
//     let userId = req.params.id,
//       userParams = getUserParams(req.body);

//     User.findByIdAndUpdate(userId, {
//       $set: userParams
//     })
//       .then(user => {
//         res.locals.redirect = `/users/${userId}`;
//         res.locals.user = user;
//         next();
//       })
//       .catch(error => {
//         console.log(`Error updating user by ID: ${error.message}`);
//         next(error);
//       });
//   },

//   delete: (req, res, next) => {
//     let userId = req.params.id;
//     User.findByIdAndRemove(userId)
//       .then(() => {
//         res.locals.redirect = "/users";
//         next();
//       })
//       .catch(error => {
//         console.log(`Error deleting user by ID: ${error.message}`);
//         next();
//       });
//   }
// };


// Debugging version

"use strict";

const User = require("../models/user"),
  getUserParams = body => {
    // 1. Log exactly what object parameters are being parsed from the raw form data
    let parsedParams = {
      name: {
        first: body.first,
        last: body.last
      },
      email: body.email,
      password: body.password,
      zipCode: body.zipCode
    };
    console.log("--- [Debug] getUserParams parsed raw body into Mongoose format: ---", parsedParams);
    return parsedParams;
  };

module.exports = {
  index: (req, res, next) => {
    User.find()
      .then(users => {
        res.locals.users = users;
        next();
      })
      .catch(error => {
        console.log(`Error fetching users: ${error.message}`);
        next(error);
      });
  },
  indexView: (req, res) => {
    res.render("users/index");
  },

  new: (req, res) => {
    console.log("--- [Debug] GET /users/new: Rendering signup form ---");
    res.render("users/new");
  },

  create: (req, res, next) => {
    console.log("--- [Debug] POST /users/create triggered ---");
    console.log("Raw form payload received (req.body):", req.body);

    let userParams = getUserParams(req.body);

    // DB Operation: Attempting insertion
    User.create(userParams)
      .then(user => {
        // 2. Log database success and match the dynamic object fields
        console.log(`--- [Debug Success] User created successfully in MongoDB! ---`);
        console.log(`Assigned ID: ${user._id} | Account: ${user.name.first} ${user.name.last}`);
        
        res.locals.redirect = "/users";
        res.locals.user = user;
        next();
      })
      .catch(error => {
        console.error("--- [Debug Error] User.create insertion failed ---");
        console.error(`Reason: ${error.message}`);
        next(error);
      });
  },

  redirectView: (req, res, next) => {
    let redirectPath = res.locals.redirect;
    console.log(`--- [Debug] redirectView: Shifting client route to -> ${redirectPath} ---`);
    if (redirectPath !== undefined) res.redirect(redirectPath);
    else next();
  },

  show: (req, res, next) => {
    let userId = req.params.id;
    console.log(`--- [Debug] GET /users/${userId}: Querying profile details ---`);
    
    User.findById(userId)
      .then(user => {
        res.locals.user = user;
        next();
      })
      .catch(error => {
        console.log(`Error fetching user by ID: ${error.message}`);
        next(error);
      });
  },

  showView: (req, res) => {
    res.render("users/show");
  },

  edit: (req, res, next) => {
    let userId = req.params.id;
    console.log(`--- [Debug] GET /users/${userId}/edit: Loading current records into form ---`);
    
    User.findById(userId)
      .then(user => {
        res.render("users/edit", {
          user: user
        });
      })
      .catch(error => {
        console.log(`Error fetching user by ID: ${error.message}`);
        next(error);
      });
  },

  update: (req, res, next) => {
    let userId = req.params.id;
    console.log(`--- [Debug] PUT /users/${userId}/update triggered ---`);
    console.log("Raw update payload received (req.body):", req.body);

    let userParams = getUserParams(req.body);

    // DB Operation: Query, locate, and update database values
    User.findByIdAndUpdate(userId, {
      $set: userParams
    })
      .then(user => {
        console.log(`--- [Debug Success] Mongoose matched ID ${userId} and updated records ---`);
        res.locals.redirect = `/users/${userId}`;
        res.locals.user = user;
        next();
      })
      .catch(error => {
        console.error(`--- [Debug Error] Database update failed for ID ${userId} ---`);
        console.error(`Reason: ${error.message}`);
        next(error);
      });
  },

  delete: (req, res, next) => {
    let userId = req.params.id;
    console.log(`--- [Debug] DELETE /users/${userId} triggered. Removing record... ---`);
    
    User.findByIdAndRemove(userId)
      .then(() => {
        console.log(`--- [Debug Success] Document ${userId} successfully wiped from MongoDB ---`);
        res.locals.redirect = "/users";
        next();
      })
      .catch(error => {
        console.log(`Error deleting user by ID: ${error.message}`);
        next(error);
      });
  }
};