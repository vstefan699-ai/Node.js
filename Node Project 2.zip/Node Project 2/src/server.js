const mongoose = require("mongoose");
const db = require("./models");

// 1. Helper to create a base tutorial
const createTutorial = function(tutorial) {
  return db.Tutorial.create(tutorial).then(docTutorial => {
    console.log("\n>> Created Tutorial:\n", docTutorial);
    return docTutorial;
  });
};

// 2. Helper to create a category
const createCategory = function(category) {
  return db.Category.create(category).then(docCategory => {
    console.log("\n>> Created Category:\n", docCategory);
    return docCategory;
  });
};

// 3. Helper to associate a tutorial to a category (Parent Reference Assignment)
const addTutorialToCategory = function(tutorialId, categoryId) {
  return db.Tutorial.findByIdAndUpdate(
    tutorialId,
    { category: categoryId },
    { returnDocument: 'after' }
  );
};

// 4. Query to find ALL tutorials belonging to a specific Category
const getTutorialsInCategory = function(categoryId) {
  return db.Tutorial.find({ category: categoryId })
    .populate("category", "name -_id") // Fetch the category details, but only return the 'name' field
    .select("-comments -images -__v"); // Strip out clutter we don't need to see right now
};

// Execution logic
const run = async function() {
  // Create Category
  var category = await createCategory({
    name: "Node.js",
    description: "Node.js core and framework tutorials"
  });

  // Create Tutorial #1 and link it to Category
  var tutorial1 = await createTutorial({
    title: "Tutorial #1 (Intro to Express)",
    author: "bezkoder"
  });
  tutorial1 = await addTutorialToCategory(tutorial1._id, category._id);
  console.log("\n>> Tutorial 1 Linked to Category:\n", tutorial1);

  // Create Tutorial #2 and link it to the SAME Category
  var tutorial2 = await createTutorial({
    title: "Tutorial #2 (Mongoose Advanced Relationships)",
    author: "bezkoder"
  });
  await addTutorialToCategory(tutorial2._id, category._id);

  // Get all tutorials that share this category's parent ID
  var tutorialsList = await getTutorialsInCategory(category._id);
  console.log("\n>> Final Query - All Tutorials In Category:\n", tutorialsList);
};

mongoose
  .connect("mongodb://localhost/bezkoder_db")
  .then(() => {
    console.log("Successfully connected to MongoDB.");
    run();
  })
  .catch(err => console.error("Connection error:", err));