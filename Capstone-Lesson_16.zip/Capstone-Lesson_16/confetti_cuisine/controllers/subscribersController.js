// const Subscriber = require('../models/subscriber');

// exports.getAllSubscribers = (req, res) => {
//     Subscriber.find({})
//     .exec()
//         .then((subscribers) => {
//             res.render("subscribers", {
//                 subscribers: subscribers
//             });
//         })
//         .catch((error) => {
//             console.log(error.message);
//             return [];
//         })
//         .then(() => {
//             console.log("Promise Complete")
//         });
// };

// exports.getSubscriptionPage = (req, res) => {
//     res.render("contact");
// };

// exports.saveSubscriber = (req, res) => {
//     let newSubscriber = new Subscriber({
//         name: req.body.name,
//         email: req.body.email,
//         zipCode: req.body.zipCode
//     });
//     newSubscriber.save()
//     .then((result) => {
//         res.render("thanks");
//     })
//     .catch((error) => {
//         res.send(error);
//     });
// };


// Debugging version

const Subscriber = require('../models/subscriber');

exports.getAllSubscribers = (req, res) => {
    Subscriber.find({})
    .exec()
        .then((subscribers) => {
            res.render("subscribers", {
                subscribers: subscribers
            });
        })
        .catch((error) => {
            console.log(error.message);
            return [];
        })
        .then(() => {
            console.log("Promise Complete")
        });
};

exports.getSubscriptionPage = (req, res) => {
    res.render("contact");
};

exports.saveSubscriber = (req, res) => {
    // 1. Log that the server received a request from the frontend form
    console.log("=== DEBUGGER: Form submission received at /subscribe ===");
    
    // 2. Log the raw data coming from the user input fields
    console.log("Incoming form data from user:", req.body);

    let newSubscriber = new Subscriber({
        name: req.body.name,
        email: req.body.email,
        zipCode: req.body.zipCode
    });

    // 3. Log that we are attempting to save this specific object to MongoDB
    console.log(`Attempting to save new subscriber: ${newSubscriber.name} (${newSubscriber.email}) to the database...`);

    newSubscriber.save()
    .then((result) => {
        // 4. Log a success message confirming database entry
        console.log("SUCCESS: New subscriber successfully saved to MongoDB!");
        res.render("thanks");
    })
    .catch((error) => {
        // 5. Log if something goes wrong (e.g., validation failure)
        console.error("ERROR: Failed to save subscriber to database.", error.message);
        res.send(error);
    });
};